https://www.slideshare.net/ShubhamSaurav11/an-implementation-of-a-geometric-and-arithmetic-captcha-without-database
https://codepen.io/isc7/pen/yJaHE
https://cdn.tutsplus.com/active/uploads/legacy/tuts/403_html5TileSwapPuzzle/demo/puzzle.html?_ga=2.226495835.790072754.1498466983-979859133.1498466978
https://www.codeproject.com/Articles/366857/Jigsaw-Puzzle-Game-in-HTML
https://www.codeproject.com/Articles/395453/Html-Jigsaw-Puzzle
https://webprofessionals.org/html5-canvas-cheatsheet/

angularjs ciruclar count down timer
http://shakogegia.github.io/angular-circle-countdown/