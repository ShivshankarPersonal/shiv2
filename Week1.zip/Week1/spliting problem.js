1. Should be responsive
2. 3 pages, login, video comment and graph so we have to use ngroute
3. captcha image puzzle with dynamic images from local drive
4. Create JSON Data for 3 users
5. &http and &q for asynchronous operatin
6. User may enter username or emil id, then call the json service and show images else hide it
7. The position of the chunk is randamized after creating the images
8. after 1 minute everthing should reset
9. 