(function(){

    angular.module("dashboard")

        .controller("loginController",function($scope){
            $scope.greeting = "hello"
        });
})();


