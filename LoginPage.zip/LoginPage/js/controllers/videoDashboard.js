(function(){

    angular.module("dashboard")

        .controller("videoDashboard",function($scope){
            $scope.greeting = "Video Dashboard"
        });
})();
